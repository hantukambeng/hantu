script-aja
==========

cara pakai

Debian 

'wget https://raw.githubusercontent.com/ardi85/script-aja/master/keopenvpn.sh --no-check-certificate -O keopenvpn.sh; chmod +x keopenvpn.sh; ./keopenvpn.sh'

Centos6

'wget https://github.com/ardi85/script-aja/raw/master/openvpn-aja-centos6 --no-check-certificate -O openvpn-aja.sh; chmod +x openvpn-aja.sh; ./openvpn-aja.sh'

mudah - mudahan lancar
